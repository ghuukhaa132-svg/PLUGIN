# Spear SMP Plugin

Custom heavenly spears for Paper 1.21.11 (Java 21). Full source, Maven project.

## ⚠️ About the .jar

This project was written in a sandboxed environment with **no internet
access**, so `mvn package` could not be run here to download the Paper API
and produce a compiled `.jar`. The Java source is complete and ready to
compile — you just need to run the build somewhere with internet access.
Three easy options:

### Option A — Build locally (30 seconds)
Requires Java 21 + Maven, both free:
```bash
mvn clean package
```
The finished jar appears at `target/spear-smp-plugin-1.0.0.jar`. Drop it into
your server's `plugins/` folder.

### Option B — Build with GitHub Actions (no local setup at all)
1. Push this folder to a GitHub repo.
2. The included `.github/workflows/build.yml` builds it automatically on
   every push.
3. Download the compiled jar from the workflow run's "Artifacts" section.

### Option C — Any online Java build sandbox
Since it's a standard Maven project, any CI/build service (Replit, Gitpod,
a VPS, a friend's PC, etc.) with internet access can run `mvn clean package`.

## Project layout

```
spear-smp-plugin/
├── pom.xml
├── src/main/resources/
│   ├── plugin.yml       # commands, permissions, sqlite library declaration
│   ├── config.yml       # all tunable values: damage, cooldowns, recipes, etc.
│   └── messages.yml     # all player-facing text
└── src/main/java/com/spearsmp/
    ├── SpearSMPPlugin.java        # entry point, wires everything together
    ├── spears/                    # SpearType enum + SpearFactory (item building)
    ├── abilities/                 # Ability interface + Dasher/Invis/GodlySmash
    ├── managers/                  # Config, Cooldown, PlayerData (+ storage/), Recipe
    ├── listeners/                 # PlayerInteractListener, CraftListener
    ├── commands/                  # /spear command + tab completion
    └── utils/                     # ItemBuilder, ActionBarUtil, ConfigTextUtil
```

## Features implemented

- **Legendary Spear**
  - *Dasher* (Shift + Right Click): dashes 5 blocks forward, deals exactly
    3 hearts of true damage (bypasses armor/enchants/Netherite) to anyone
    struck, ignores hunger/slowdown during the dash, 30s cooldown, action bar
    cooldown message, sound + particles.
  - *Invis* (Shift + Right Click again, within a configurable window):
    15s full invisibility including worn armor (armor is temporarily removed
    and restored automatically), 30s cooldown, action bar countdown.
- **Godly Spear**
  - *Godly Smash* (Shift + Right Click): launches 10 blocks up, free-falls,
    and on landing deals exactly 5 hearts of true damage + knockback to
    every player within a 10-block radius, with a big particle/sound payoff.
    The user takes no fall damage from their own smash. 30s cooldown.
- Both spears: custom name, custom lore, CustomModelData, glow effect,
  unbreakable (cannot be repaired at an anvil since there's nothing to repair
  with — Unbreakable items ignore durability entirely).
- **Crafting**: shaped recipes fully defined in `config.yml` (shape,
  ingredients, result amount, recipe key) — edit and `/spear reload`, no
  restart needed.
- **One-time-craft-per-player**: enforced permanently via persisted data
  (`players.yml` by default, optional SQLite `players.db` via
  `storage.type: sqlite` in config.yml). Attempting to re-craft shows
  "You have already crafted this legendary weapon." and the crafting-grid
  preview hides the result item entirely once already crafted.
- **Commands**: `/spear give <player> <legendary|godly>`, `/spear reload`,
  `/spear resetcraft <player> [spear]` — all with tab completion.
- **Permissions**: `spear.admin`, `spear.use.legendary`, `spear.use.godly`.

## Extending with a new spear

1. Add a constant to `SpearType`.
2. Add a `spears.<key>` section to `config.yml` (display name, lore, model
   data, abilities, recipe).
3. Implement any new `Ability` classes needed.
4. Wire activation into `PlayerInteractListener`.

Nothing else in the plugin needs to change — commands, crafting, permissions,
and persistence all iterate over the `SpearType` enum automatically.
